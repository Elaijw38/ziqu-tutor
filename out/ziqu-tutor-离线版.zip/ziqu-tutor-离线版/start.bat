@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "PORT=8780"
set "ZQ_HOST=127.0.0.1"

rem 如果存在 config.local.env，把里面的 KEY=VALUE 读进环境变量（# 开头是注释）
if exist "config.local.env" (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in ("config.local.env") do (
    if not "%%~a"=="" if not "%%~b"=="" set "%%~a=%%~b"
  )
)

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo [x] 没有找到 Python。
  echo     请先安装 Python 3.9 或更高版本，安装时勾选 "Add Python to PATH"。
  echo     下载：https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)

echo.
echo   甲骨文 AI 助教 · 龟宝
echo   地址：http://127.0.0.1:%PORT%
echo   自检：http://127.0.0.1:%PORT%/api/health
echo   关闭这个窗口即停止服务。
echo.

start "" "http://127.0.0.1:%PORT%"
%PY% src\server.py %PORT%

echo.
echo 服务已停止。按任意键关闭窗口。
pause >nul
